const FLIGHT_DATA = require('./flight-data.json');

// given a source and destination, return the cheapest flight
module.exports.getFlightData = (cityFrom, cityTo) => {
    if (cityFrom && FLIGHT_DATA[cityFrom] && cityTo && FLIGHT_DATA[cityFrom][cityTo] ) {
        return FLIGHT_DATA[cityFrom][cityTo]
    }
    return {
        "cost": ""
    };
};

// given a source, return list of cities that can be travelled to
module.exports.getToCityList = (cityFrom) => {
    if (cityFrom && FLIGHT_DATA[cityFrom] ) {
        return FLIGHT_DATA[cityFrom]
    }
    return {
        "city": ""
    };
};